async def test_root(client):
    response = await client.get("/")
    assert response.status_code == 200
    assert "NexaPilot AI" in response.json()["message"]


async def test_health(client):
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}
